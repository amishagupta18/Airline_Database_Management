--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 14.5
-- Dumped by pg_dump version 14.5

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE airdata;
--
-- Name: airdata; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE airdata WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'C';


ALTER DATABASE airdata OWNER TO postgres;

\connect airdata

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: airline_company; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.airline_company (
    airline character varying(50) NOT NULL,
    parent_airline character varying(50) NOT NULL
);


ALTER TABLE public.airline_company OWNER TO postgres;

--
-- Name: airplane_model; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.airplane_model (
    aircraft_type character varying(50) NOT NULL,
    unit_cost double precision
);


ALTER TABLE public.airplane_model OWNER TO postgres;

--
-- Name: employees; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.employees (
    name character varying(50),
    last_name character varying(50),
    employee_id character varying(50) NOT NULL
);


ALTER TABLE public.employees OWNER TO postgres;

--
-- Name: flights; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.flights (
    origin_airport character varying(50),
    origin_city character varying(50),
    destination_airport character varying(50),
    destination_city character varying(50),
    seats integer,
    passengers integer,
    flight_id character varying(50) NOT NULL,
    tail_number character varying(50) NOT NULL,
    airline character varying(50)
);


ALTER TABLE public.flights OWNER TO postgres;

--
-- Name: flying_in; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.flying_in (
    aircraft_type character varying(50),
    flight_id character varying(50)
);


ALTER TABLE public.flying_in OWNER TO postgres;

--
-- Name: flying_on; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.flying_on (
    customer_id character varying(50),
    flight_id character varying(50)
);


ALTER TABLE public.flying_on OWNER TO postgres;

--
-- Name: owns; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.owns (
    flight_id character varying(50),
    airline character varying(50)
);


ALTER TABLE public.owns OWNER TO postgres;

--
-- Name: passengers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.passengers (
    customer_id character varying(50) NOT NULL,
    customer_name character varying(50),
    phone_number character varying(50)
);


ALTER TABLE public.passengers OWNER TO postgres;

--
-- Name: working_on; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.working_on (
    employee_id character varying(50),
    flight_id character varying(50),
    tail_number character varying(50)
);


ALTER TABLE public.working_on OWNER TO postgres;

--
-- Name: works_for; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.works_for (
    airline character varying(50),
    employee_id character varying(50)
);


ALTER TABLE public.works_for OWNER TO postgres;

--
-- Data for Name: airline_company; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.airline_company (airline, parent_airline) FROM stdin;
\.
COPY public.airline_company (airline, parent_airline) FROM '$$PATH$$/3362.dat';

--
-- Data for Name: airplane_model; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.airplane_model (aircraft_type, unit_cost) FROM stdin;
\.
COPY public.airplane_model (aircraft_type, unit_cost) FROM '$$PATH$$/3363.dat';

--
-- Data for Name: employees; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.employees (name, last_name, employee_id) FROM stdin;
\.
COPY public.employees (name, last_name, employee_id) FROM '$$PATH$$/3364.dat';

--
-- Data for Name: flights; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.flights (origin_airport, origin_city, destination_airport, destination_city, seats, passengers, flight_id, tail_number, airline) FROM stdin;
\.
COPY public.flights (origin_airport, origin_city, destination_airport, destination_city, seats, passengers, flight_id, tail_number, airline) FROM '$$PATH$$/3365.dat';

--
-- Data for Name: flying_in; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.flying_in (aircraft_type, flight_id) FROM stdin;
\.
COPY public.flying_in (aircraft_type, flight_id) FROM '$$PATH$$/3369.dat';

--
-- Data for Name: flying_on; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.flying_on (customer_id, flight_id) FROM stdin;
\.
COPY public.flying_on (customer_id, flight_id) FROM '$$PATH$$/3370.dat';

--
-- Data for Name: owns; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.owns (flight_id, airline) FROM stdin;
\.
COPY public.owns (flight_id, airline) FROM '$$PATH$$/3371.dat';

--
-- Data for Name: passengers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.passengers (customer_id, customer_name, phone_number) FROM stdin;
\.
COPY public.passengers (customer_id, customer_name, phone_number) FROM '$$PATH$$/3366.dat';

--
-- Data for Name: working_on; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.working_on (employee_id, flight_id, tail_number) FROM stdin;
\.
COPY public.working_on (employee_id, flight_id, tail_number) FROM '$$PATH$$/3367.dat';

--
-- Data for Name: works_for; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.works_for (airline, employee_id) FROM stdin;
\.
COPY public.works_for (airline, employee_id) FROM '$$PATH$$/3368.dat';

--
-- Name: airplane_model Aircraft_Type; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.airplane_model
    ADD CONSTRAINT "Aircraft_Type" UNIQUE (aircraft_type);


--
-- Name: flights Flight_ID; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.flights
    ADD CONSTRAINT "Flight_ID" UNIQUE (flight_id);


--
-- Name: airline_company airline; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.airline_company
    ADD CONSTRAINT airline UNIQUE (airline);


--
-- Name: airplane_model airplane_model_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.airplane_model
    ADD CONSTRAINT airplane_model_pkey PRIMARY KEY (aircraft_type);


--
-- Name: employees employees_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT employees_pkey PRIMARY KEY (employee_id);


--
-- Name: flights flights_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.flights
    ADD CONSTRAINT flights_pkey PRIMARY KEY (flight_id, tail_number);


--
-- Name: passengers passangers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.passengers
    ADD CONSTRAINT passangers_pkey PRIMARY KEY (customer_id);


--
-- Name: works_for a; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.works_for
    ADD CONSTRAINT a FOREIGN KEY (airline) REFERENCES public.airline_company(airline) NOT VALID;


--
-- Name: flying_in aircraft_type; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.flying_in
    ADD CONSTRAINT aircraft_type FOREIGN KEY (aircraft_type) REFERENCES public.airplane_model(aircraft_type) NOT VALID;


--
-- Name: working_on e; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.working_on
    ADD CONSTRAINT e FOREIGN KEY (employee_id) REFERENCES public.employees(employee_id) NOT VALID;


--
-- Name: works_for e; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.works_for
    ADD CONSTRAINT e FOREIGN KEY (employee_id) REFERENCES public.employees(employee_id) NOT VALID;


--
-- Name: working_on f; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.working_on
    ADD CONSTRAINT f FOREIGN KEY (flight_id) REFERENCES public.flights(flight_id) NOT VALID;


--
-- Name: flying_on f3; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.flying_on
    ADD CONSTRAINT f3 FOREIGN KEY (customer_id) REFERENCES public.passengers(customer_id) NOT VALID;


--
-- Name: flying_on f4; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.flying_on
    ADD CONSTRAINT f4 FOREIGN KEY (flight_id) REFERENCES public.flights(flight_id) NOT VALID;


--
-- Name: owns f5; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.owns
    ADD CONSTRAINT f5 FOREIGN KEY (flight_id) REFERENCES public.flights(flight_id) NOT VALID;


--
-- Name: owns f6; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.owns
    ADD CONSTRAINT f6 FOREIGN KEY (airline) REFERENCES public.airline_company(airline) NOT VALID;


--
-- Name: flying_in flight_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.flying_in
    ADD CONSTRAINT flight_id FOREIGN KEY (flight_id) REFERENCES public.flights(flight_id) NOT VALID;


--
-- Name: TABLE airline_company; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON TABLE public.airline_company FROM postgres;
GRANT ALL ON TABLE public.airline_company TO pg_write_all_data WITH GRANT OPTION;
GRANT ALL ON TABLE public.airline_company TO postgres WITH GRANT OPTION;


--
-- Name: TABLE airplane_model; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON TABLE public.airplane_model FROM postgres;
GRANT ALL ON TABLE public.airplane_model TO pg_write_all_data WITH GRANT OPTION;
GRANT ALL ON TABLE public.airplane_model TO postgres WITH GRANT OPTION;


--
-- Name: TABLE employees; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON TABLE public.employees FROM postgres;
GRANT ALL ON TABLE public.employees TO pg_write_all_data WITH GRANT OPTION;
GRANT ALL ON TABLE public.employees TO postgres WITH GRANT OPTION;


--
-- Name: TABLE flights; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON TABLE public.flights FROM postgres;
GRANT ALL ON TABLE public.flights TO pg_write_all_data WITH GRANT OPTION;
GRANT ALL ON TABLE public.flights TO postgres WITH GRANT OPTION;


--
-- Name: TABLE flying_in; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON TABLE public.flying_in FROM postgres;
GRANT ALL ON TABLE public.flying_in TO pg_write_all_data WITH GRANT OPTION;
GRANT ALL ON TABLE public.flying_in TO postgres WITH GRANT OPTION;


--
-- Name: TABLE flying_on; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.flying_on TO pg_write_all_data WITH GRANT OPTION;


--
-- Name: TABLE passengers; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON TABLE public.passengers FROM postgres;
GRANT ALL ON TABLE public.passengers TO pg_write_all_data WITH GRANT OPTION;
GRANT ALL ON TABLE public.passengers TO postgres WITH GRANT OPTION;


--
-- Name: TABLE working_on; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON TABLE public.working_on FROM postgres;
GRANT ALL ON TABLE public.working_on TO pg_write_all_data WITH GRANT OPTION;
GRANT ALL ON TABLE public.working_on TO postgres WITH GRANT OPTION;


--
-- Name: TABLE works_for; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON TABLE public.works_for FROM postgres;
GRANT ALL ON TABLE public.works_for TO pg_write_all_data WITH GRANT OPTION;
GRANT ALL ON TABLE public.works_for TO postgres WITH GRANT OPTION;


--
-- PostgreSQL database dump complete
--

